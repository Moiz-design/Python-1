f=lambda x: x**4-5*x +1
# x1=int(input("Enter The first Guess"))
# x0=x1-1
x=[]
y=[]
for i in range (-100,100):
    xi=f(i)
    x.append(xi)
    y.append(i)
k=y.index(min(y))
x1=x[i]
x0=x1-i

for i in range (1,1000):
    secant=(x1-x0)/(f(x1)-f(x0))
    c =  x1- (f(x1)*secant)
    if abs(c-x1)<0.0001 :
        print(f"The Value of equation is {c=} and no of iteration it take is {i=}")
        break
    x1,x0=c,x1