x=0
y=0
z=0
for i in range (1,100000):
    x_new = (3+y-z)/4
    y_new=  (9- 2*x_new  -z)/6
    z_new= (4 -x_new - y_new)/5
    if abs(x_new-x)<0.001 and abs(y_new-y)<0.001 :
        print(f"The Solution of equation is {x=},{y=} and {z=} and No of iteratonn it take is {i=}")
        break
    x,y,z=x_new,y_new,z_new
