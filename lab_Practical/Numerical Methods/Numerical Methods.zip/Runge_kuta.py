import matplotlib.pyplot as plt

# Define the differential equation dy/dx = f(x, y)
def f(x, y):
    return x + y

# Runge-Kutta 4th Order Method
h = 0.1
x0 = 0
y0 = 1
x_end = 1
x_vals = [x0]
y_vals = [y0]

while x0 + h <= x_end:
    k1 = h * f(x0, y0)
    k2 = h * f(x0 + h/2, y0 + k1/2)
    k3 = h * f(x0 + h/2, y0 + k2/2)
    k4 = h * f(x0 + h, y0 + k3)
    y1 = y0 + (k1 + 2*k2 + 2*k3 + k4) / 6
    x0 += h
    y0 = y1
    x_vals.append(x0)
    y_vals.append(y0)

print(f"Final value using Runge-Kutta y({x_end:.4f}) = {y0:.4f}")

# Modified Euler Method
print("\nModified Euler Method:")
x0 = 0
y0 = 1
h = 0.2
x1 = 1
x_mod = [x0]
y_mod = [y0]
n = int((x1 - x0) / h)

for i in range(n):
    k = f(x0, y0)
    y1 = y0 + h * f(x0 + h/2, y0 + k * h/2)
    x0 += h
    y0 = y1
    x_mod.append(x0)
    y_mod.append(y0)

print(f"The value of y({x0}) using Modified Euler is {y1:.4f}")

# Euler Method
print("\nEuler Method:")
x_euler = 0
y_euler = 1
h_euler = 0.2
x_end = 1
x_vals_euler = [x_euler]
y_vals_euler = [y_euler]
n_euler = int((x_end - x_euler) / h_euler)

for _ in range(n_euler):
    y_next = y_euler + h_euler * f(x_euler, y_euler)
    x_euler += h_euler
    y_euler = y_next
    x_vals_euler.append(x_euler)
    y_vals_euler.append(y_euler)

print(f"The value of y({x_euler}) using Euler is {y_euler:.4f}")

# Plotting the results222222
plt.plot(x_vals, y_vals, marker='o', color="lime", label="Runge-Kutta")
plt.plot(x_vals_euler, y_vals_euler, marker="^",color="khaki", label="Euler")
plt.plot(x_mod, y_mod, marker="*", color="black", label="Modified Euler")
plt.xlabel('x')
plt.ylabel('y')
plt.title('Comparison of Numerical Methods')
plt.legend()
plt.grid(True)
plt.show()
