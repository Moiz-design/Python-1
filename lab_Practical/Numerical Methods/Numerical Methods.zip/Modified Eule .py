import matplotlib.pyplot as plt
y0 = 1
x0 = 0
x1 = 1
h=.2
y=[y0]
x=[x0]
def Diff(x, y):
    return x + y
n=int((x1-x0)/h)
for i in range(0,n):
    yi=y0+h*Diff((x0+h/2),y0+(Diff(x0,y0)/2))
    print(f"{x0} and {y0}")
    y.append(yi)
    y0 = yi  # Update y0 for next step
    x0 = x0 + h
    x.append(x0)
print(f"The Value of y({x0}) is {yi}")
plt.plot(x,y,marker="*",color='lime')
plt.show()