import numpy as np
import math
x_matrix = np.array([[1 ,-1 ,2],[1 ,2 ,3], [ 3, -4, 5]],np.float16)
y_matrix=np.array([[3],[5],[-13]],np.float16)
n=len(y_matrix)
c=np.hstack((x_matrix , y_matrix))
print(c)
for i in range (0,n):# 
    for j in range(i+1,n):
            m=c[j,i]/c[i,i]
            c[j,:]=c[j,:]-(m*c[i,:])
print(c)
# Back substitution (fixed part)
x = c[2, 3] / c[2, 2]
y = (c[1, 3] - c[1, 2] * x) / c[1, 1]
z = (c[0, 3] - c[0, 2] * x - c[0, 1] * y) / c[0, 0]
print(f"\nThe values of the variables are: x = {x}, y = {y}, z = {z}")