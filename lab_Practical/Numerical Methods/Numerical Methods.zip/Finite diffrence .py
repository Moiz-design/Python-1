f = lambda x, y: 6 * y**2 - x

# Initial conditions
x_initial = 0
y_initial = 1
y_end = 5
x_end = 1
h = 1 / 3

# Calculate number of steps
k = int((x_end - x_initial) / h)

# Initialize y and x arrays
y = [0] * (k + 1)
y[0] = y_initial
y[-1] = y_end
print(y )
x = [x_initial + i * h for i in range(k + 1)]  # Generate x values from initial to end

# Start iterative calculation.33
for i in range(1, k):
    # Set previous and next points for y
    y1 = y[i-1] + h**2 * f(x[i-1], y[i-1]) 
    y2 = y[i-1] + h**2 * f(x[i], y[i])
    # Update y values for the next step
    y[i] = y1  # You can adjust this update as needed for the problem at hand
    print(f"x: {x[i]}, y: {y[i]}")

# Printing the final y values
print("Final y values:", y)
