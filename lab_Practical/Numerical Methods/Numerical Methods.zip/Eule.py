import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

y0 = 1
x0 = 0
x1 = 1
h = 0.2

y = [y0]
x = [x0]
z = [x0**2 + y0]  # Initialize z

def Diff(x, y):
    return x + y

n = int((x1 - x0) / h)
for i in range(n):
    yi = y0 + h * Diff(x0, y0)
    y.append(yi)
    x0 = x0 + h
    x.append(x0)
    print(y0)
    z.append(x0 + yi)  # z = x + y
    y0 = yi

print(f"The Value of y({x0}) is {yi}")

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(x, y, z, marker='X', color='lime')
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Z axis (X+Y)')
plt.show()
