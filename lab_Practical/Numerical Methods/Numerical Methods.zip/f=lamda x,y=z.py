f = lambda x, y, z: z
g = lambda x, y, z: 72*x - 8*(x**2) + 2*y

h = 3
z_overshoot = 4
z_undershoot = -24
y_overshoot = 0
y_undershoot = 0

x0 = 0
x_end = 9

while x0 < x_end:
    # Overshoot path
    y1_over = y_overshoot + h * f(x0, y_overshoot, z_overshoot)
    z1_over = z_overshoot + h * g(x0, y_overshoot, z_overshoot)

    # Undershoot path
    y1_under = y_undershoot + h * f(x0, y_undershoot, z_undershoot)
    z1_under = z_undershoot + h * g(x0, y_undershoot, z_undershoot)

    # Update for next step
    x0 += h
    y_overshoot, z_overshoot = y1_over, z1_over
    y_undershoot, z_undershoot = y1_under, z1_under

# Final values
print(f"At x = {x0}:")
print(f"  Overshoot -> y = {y_overshoot}, z = {z_overshoot}")
print(f"  Undershoot -> y = {y_undershoot}, z = {z_undershoot}")

# Linear interpolation to estimate z0 that gives y(x=9) = 0
y2, y1 = y_overshoot, y_undershoot
z2, z1 = 4, -24  # Initial guesses for z, not final z


z_correct = z1 + ((0 - y1) / (y2 - y1)) * (z2 - z1)
print(f"Estimated initial z for y(x=9) = 0: {z_correct}"+"\n")
print(range(9,1,-1))