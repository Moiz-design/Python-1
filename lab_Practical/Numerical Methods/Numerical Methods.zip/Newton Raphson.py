import sympy as s
x=s.Symbol('x')# Instructing python to treat this as varible usign sympy
f=x**3-5*x +1# Defining a fxn
dfdx= s.diff(f,x)
x0=float(input("Enter the first guess "))
for i in range (1,1000):
    k1=f.subs(x,x0).evalf()
    k = dfdx.subs(x, x0).evalf()  # as f is symblolic fxn we need to instruct python for to replace x by c no x
    x_new = x0 - (k1 / k)# Newton Raphson 
    if abs((x_new)-(x0))<0.0001 :
        print(f"The Value of equation is {x_new=} and no of iteration it take is {i=}")
        break
    x0=float(x_new)