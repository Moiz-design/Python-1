import numpy as np 
import  matplotlib.pyplot as plt
h = 1
k = 1
x = np.arange(0, 4+h, h)
print(x)
t = np.arange(0,4+k, k)
array = np.zeros((len(x), len(t)))
m=len(x)
n=len(t)
array[0,:] = x*(10-x)  # initial condition at t=0
array[:,0],array[:,-1]= 0,0
for j in range(1,n-1):  # Loop over t which is time and is row
    for i in range(1, m-1):  # This loops over x and is colum  
        # Bender-Schmidt (explicit) update formula
        array[j,i] = (array[j - 1, i - 1] + array[j - 1, i + 1]) / 2
np.set_printoptions(precision=3)
print(array)
plt.plot(x,array[-1,:],marker="*", label="Last Row ",color="lime")
plt.plot(x,array[-2,:],marker="p", label="Secod Last Row",color="olive")
plt.plot(x,array[-3,:],marker="^", label="row 3",color="mediumvioletred")
plt.xlabel("x-axis")
plt.grid("True")
plt.legend()
plt.show()
