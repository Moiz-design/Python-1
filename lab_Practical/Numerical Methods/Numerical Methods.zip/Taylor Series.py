def function (x,y):
    return y+x
def derivate (x,y):
    return 1+function(x,y)
import matplotlib.pyplot as plt
y0 = 1
x0 = 0
x1 = 1
y=[y0]
x=[x0]
h = 0.1
n=int((x1-x0)/h)
for i in range(0,n):
    first_derivative=function(x0,y0)
    seconde_derivative = function(x0,y0)
    yi=y0 + h*first_derivative + seconde_derivative*(h**2/2)
    print(yi)
    y.append(yi)
    y0 = yi  # Update y0 for next step
    x0 = x0 + h
    x.append(x0)
print(f"The Value of y({x0:.2f}) is {yi:.3}")
plt.plot(x,y,marker="o",color='lime')
plt.grid("True")
plt.show()