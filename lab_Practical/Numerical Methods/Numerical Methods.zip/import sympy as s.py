import sympy as s
import numpy as np
from scipy.misc import derivative
f=lambda x: x**4-5*x +1
x0=float(input("Enter the first guess "))
for i in range (1,1000):
    dy_dx=derivative(f,x0)
    x_new=x0 - f(x0)/dy_dx
    if abs(x_new - x0)<0.0001:
        print(f"The root of equation is {x_new} and no of iteration it took {i}")
        break
    x0=x_new