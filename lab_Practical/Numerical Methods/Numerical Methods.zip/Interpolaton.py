import math as m
import numpy as np

# Sample data points
x_list = np.array([0, 1, 2, 3], dtype=float)
y_list = np.array([1, 2, 4, 8], dtype=float)

n = len(x_list)
T1 = np.zeros((n, n))
T1[:, 0] = y_list  # Assigning the first column

# Creating the divided difference table
for i in range(1, n):
    for j in range(1, i + 1):
        T1[i, j] = T1[i, j - 1] - T1[i - 1, j - 1]
# Taking user input
x1 = float(input("Enter value of x for which you want to find the value: "))
h = x_list[1] - x_list[0]
u = (x1 - x_list[0]) / h
q = u
y0 = y_list[0]
# Applying Newton's Forward Difference Formula
for i in range(1, n):
    y0 += (T1[i, i] * q) / m.factorial(i)
    q *= (u - i)
print(f"Interpolated value at x = {x1}: {y0}")
