x_old=0
y_old=0
z_old=0
for i in range (1,100000):
    x = (3+y_old-z_old)/4
    y=  (9- 2*x_old  -z_old)/6
    z= (4 -x_old - y_old)/5
    if abs(x_old-x)<0.001 and abs(y-y)<0.001 :
        print(f"The Solution of equation is {x_old=},{y=} and {z=} and No of iteratonn it take is {i=}")
        break
    x_old,y_old,z_old=x,y,z

    
