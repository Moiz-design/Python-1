import math as m
f=lambda x: x**3-5*x +1
a = int(input("Enter intial guess"))
b=int(input("enter Secodary guess"))
if f(a)*f(b)>0: raise ValueError ("a and b must be on diffrent side of zero")
c_old = 0
for i in range (1,1000):
    c =  (a*f(b)-b*f(a))/(f(b)-f(a))
    if f(c)*f(b)<0:
        a=c
    elif f(c)*f(a)<0:
        b=c
    if abs(c-c_old)<0.0001 :
        print(f"The Value of equation is {c=} and no of iteration it take is {i=}")
        break
    c_old=c